﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using Microsoft.Dynamics.AX.Framework.Linq.Data;
using Microsoft.Dynamics.AX.Framework.Linq.Data.Common;
using Microsoft.Dynamics.AX.Framework.Linq.Data.ManagedInteropLayer;
using Microsoft.Dynamics.AX.ManagedInterop;

namespace AX62Linq
{
    /// <summary>
    /// Interaction logic for CustomerSearch.xaml
    /// </summary>
    public partial class CustomerSearch : Window
    {
        public CustomerSearch()
        {
            InitializeComponent();
        }

        public void LoadCustomers(string customerGroup)
        {
            QueryProvider provider = new AXQueryProvider(null);
            QueryCollection<CustTable> custTableCollection = new QueryCollection<CustTable>(provider);

            var customers = from c in custTableCollection where c.CustGroup == customerGroup select new { c.AccountNum, c.DlvMode };

            CustomerList.ItemsSource = customers;
        }

        private void SearchBtn_Click(object sender, RoutedEventArgs e)
        {
            LoadCustomers(CustGroup.Text);
        }
    }
}
